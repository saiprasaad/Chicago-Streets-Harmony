import 'package:chicago_social/models/unit.dart';

class Parade {
  String name;
  String date;
  String description;
  List<Unit> units;


  Parade({required this.name, required this.date, required this.description, required this.units});


}